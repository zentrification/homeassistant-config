# Blacklist a repository

As a developer you can blacklist your repositories.

A blacklisted repository can not be added to HACS.

To add a repository to the blacklist add it to the `blacklist` file in the [`data` branch](https://github.com/custom-components/hacs/blob/data/repositories)

_NB!: The list is case sensitive._

<!-- Disable sidebar -->
<script>
let sidebar = document.getElementsByClassName("col-md-3")[0];
sidebar.parentNode.removeChild(sidebar);
document.getElementsByClassName("col-md-9")[0].style['padding-left'] = "0";
</script>
<!-- Disable sidebar -->